# A sample for Uploading file to AWS S3 with ASP.NET Core MVC
A simple ASP.NET Core MVC project for uploading file to AWS S3 storage

you must your own aws accesskey and secretkey for testing this sample.
