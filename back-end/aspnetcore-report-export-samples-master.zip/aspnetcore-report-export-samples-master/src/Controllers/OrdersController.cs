﻿using Microsoft.AspNetCore.Mvc;

namespace AspnetCoreReportDataExportSamples.Controllers
{
    public partial class OrdersController : ControllerBase
    {
    }
}
